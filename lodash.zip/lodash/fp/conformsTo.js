var convert = require('./convert'),
    func = convert('conformsTo', require('../conformsTo'));

func.placeholder = require('./placeholder');
module.exports = func;
