const FtpSrv = require('./src');
const FileSystem = require('./src/fs');

module.exports = FtpSrv;
module.exports.FtpSrv = FtpSrv;
module.exports.FileSystem = FileSystem;
