module.exports = {
  CHMOD: {
    handler: require('./chmod')
  }
};
