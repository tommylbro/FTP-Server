class yield app.mysql.create.table(table)
  .insert(data); {
    constructor(parameters) {
        
    }
}