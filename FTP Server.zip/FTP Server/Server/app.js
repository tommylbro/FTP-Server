body {
    font-family: Arial, sans-serif;
    margin: 0;
    padding: 0;
    background-color: #f4f4f4;
  }
  
  header {
    background: #007BFF;
    color: #fff;
    padding: 1em 0;
    text-align: center;
  }
  
  main {
    padding: 20px;
  }
  
  form, section {
    margin-bottom: 20px;
  }
  
  button {
    background-color: #007BFF;
    color: white;
    border: none;
    padding: 10px 15px;
    cursor: pointer;
  }
  
  button:hover {
    background-color: #0056b3;
  }
  