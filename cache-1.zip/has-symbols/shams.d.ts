declare function hasSymbolShams(): boolean;

export = hasSymbolShams;